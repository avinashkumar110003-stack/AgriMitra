import type { FarmAiChatMessage } from '@workspace/api-client-react';
import { ArrowUp, Check, ChevronRight, CircleHelp, Leaf, Moon, RotateCcw, Sparkles, Sun, X } from 'lucide-react';
import { useFarmAiStream } from '@/hooks/use-farm-ai-stream';
import { FarmMarkdown } from '@/components/farm-markdown';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { FormEvent, RefObject } from 'react';

type KnowledgeEntry = { title: string; content: string; searchable: string };
type ChatMessage = FarmAiChatMessage & { id: number };

const starterQuestions = [
  'How can I improve my soil naturally?',
  'What does this farm do about Urea and DAP?',
  'How do earthworms help the soil?',
];

function cleanText(value: string | null | undefined) {
  return (value ?? '').replace(/\s+/g, ' ').trim();
}

function extractKnowledge(doc: Document): KnowledgeEntry[] {
  const entries: KnowledgeEntry[] = [];
  const seen = new Set<string>();

  const addEntry = (title: string, content: string) => {
    const cleanTitle = cleanText(title);
    const cleanContent = cleanText(content);
    if (!cleanTitle && !cleanContent) return;
    const key = `${cleanTitle}|${cleanContent}`;
    if (seen.has(key)) return;
    seen.add(key);
    entries.push({
      title: cleanTitle || 'Farm site',
      content: cleanContent,
      searchable: `${cleanTitle} ${cleanContent}`.toLowerCase(),
    });
  };

  doc.querySelectorAll('section').forEach((section) => {
    const heading = cleanText(section.querySelector('h1, h2, h3')?.textContent) || 'Farm information';
    addEntry(heading, cleanText(section.querySelector(':scope > p')?.textContent));
    section.querySelectorAll('.card').forEach((card) => {
      const title = cleanText(card.querySelector('h3, h4')?.textContent)
        || cleanText(card.getAttribute('data-info-title'))
        || heading;
      const description = cleanText(card.querySelector('.card-body p, p')?.textContent);
      const article = cleanText(card.getAttribute('data-info'));
      const subtype = cleanText(card.querySelector('.subtype-tag')?.textContent);
      addEntry(`${heading} — ${title}`, [subtype, description, article].filter(Boolean).join(' '));
    });
    const sectionText = cleanText(section.querySelector(':scope > .farm-plan, :scope > .loop, :scope > .calc-box, :scope > .quiz-container')?.textContent);
    if (sectionText) addEntry(heading, sectionText);
  });

  doc.querySelectorAll('.smart-widget, .farm-plan, .loop-item, .res-card, article').forEach((element) => {
    const nearestHeading = element.closest('section')?.querySelector('h1, h2, h3')?.textContent || 'Farm site details';
    addEntry(cleanText(nearestHeading), cleanText(element.textContent));
  });

  return entries;
}

function retrieveKnowledge(question: string, entries: KnowledgeEntry[]) {
  const stopWords = new Set(['about', 'after', 'also', 'and', 'are', 'can', 'does', 'for', 'from', 'have', 'help', 'how', 'into', 'our', 'that', 'the', 'this', 'what', 'when', 'where', 'which', 'with', 'would', 'you', 'your']);
  const terms = question.toLowerCase().match(/[a-z0-9]+/g)?.filter((term) => term.length > 2 && !stopWords.has(term)) ?? [];
  const ranked = entries.map((entry) => {
    const score = terms.reduce((sum, term) => {
      const count = entry.searchable.split(term).length - 1;
      return sum + (count ? Math.min(count, 3) * (entry.title.toLowerCase().includes(term) ? 3 : 1) : 0);
    }, 0);
    return { entry, score };
  }).filter(({ score }) => score > 0).sort((a, b) => b.score - a.score).slice(0, 7);

  return ranked.map(({ entry }) => `## ${entry.title}\n${entry.content}`).join('\n\n').slice(0, 23500);
}

function errorMessage(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  return 'The assistant could not connect just now. Check your connection and try again.';
}

export function FarmAiChat({ iframeRef, onOpenChange }: {
  iframeRef: RefObject<HTMLIFrameElement | null>;
  onOpenChange?: (open: boolean) => void;
}) {
  const { stream, abort, isStreaming } = useFarmAiStream();
  const [isOpen, setIsOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [knowledgeEntries, setKnowledgeEntries] = useState<KnowledgeEntry[]>([]);
  const [knowledgeReady, setKnowledgeReady] = useState(false);
  const [failedRequest, setFailedRequest] = useState<{ question: string; history: FarmAiChatMessage[] } | null>(null);
  const [error, setError] = useState('');
  const [isDark, setIsDark] = useState(() => {
    try {
      if (typeof window === 'undefined') return false;
      const savedTheme = window.localStorage.getItem('farm-ai-chat-theme');
      return savedTheme
        ? savedTheme === 'dark'
        : window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
    } catch {
      return false;
    }
  });
  const [showLatestButton, setShowLatestButton] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const threadRef = useRef<HTMLDivElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const messageId = useRef(0);
  const abortingRef = useRef(false);
  const isAtBottomRef = useRef(true);
  const entriesRef = useRef(knowledgeEntries);
  entriesRef.current = knowledgeEntries;

  const refreshKnowledge = useCallback(() => {
    const doc = iframeRef.current?.contentDocument;
    if (!doc?.body) return;
    const extracted = extractKnowledge(doc);
    setKnowledgeEntries(extracted);
    setKnowledgeReady(true);
  }, [iframeRef]);

  useEffect(() => {
    const frame = iframeRef.current;
    if (!frame) return;
    frame.addEventListener('load', refreshKnowledge);
    if (frame.contentDocument?.readyState === 'complete') refreshKnowledge();
    return () => frame.removeEventListener('load', refreshKnowledge);
  }, [iframeRef, refreshKnowledge]);

  const openChat = useCallback((open: boolean) => {
    if (!open && isStreaming) {
      abortingRef.current = true;
      abort();
    }
    setIsOpen(open);
    onOpenChange?.(open);
    if (open) window.setTimeout(() => inputRef.current?.focus(), 80);
    else window.setTimeout(() => launcherRef.current?.focus(), 0);
  }, [abort, isStreaming, onOpenChange]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') openChat(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, openChat]);

  useEffect(() => {
    try {
      window.localStorage.setItem('farm-ai-chat-theme', isDark ? 'dark' : 'light');
    } catch {
      // The chat remains usable when browser storage is unavailable.
    }
  }, [isDark]);

  useEffect(() => {
    const thread = threadRef.current;
    if (!thread || !isAtBottomRef.current) return;
    thread.scrollTop = thread.scrollHeight;
    setShowLatestButton(false);
  }, [messages, isStreaming, error]);

  const contextFor = useCallback((question: string) => retrieveKnowledge(question, entriesRef.current), []);
  const sendQuestion = useCallback(async (rawQuestion: string, historyOverride?: FarmAiChatMessage[]) => {
    const question = rawQuestion.trim();
    if (!question || isStreaming) return;
    const history = historyOverride ?? messages
      .filter((message) => message.content.trim())
      .map(({ role, content }) => ({ role, content }))
      .slice(-12);
    setError('');
    setFailedRequest({ question, history });
    const userId = historyOverride ? undefined : ++messageId.current;
    const assistantId = ++messageId.current;
    if (userId !== undefined) {
      setMessages((current) => [
        ...current,
        { id: userId, role: 'user', content: question },
        { id: assistantId, role: 'assistant', content: '' },
      ]);
    } else {
      setMessages((current) => [
        ...current,
        { id: assistantId, role: 'assistant', content: '' },
      ]);
    }
    abortingRef.current = false;
    setDraft('');
    try {
      await stream({
        question,
        knowledgeContext: contextFor(question),
        history,
      }, {
        onDelta: (chunk) => {
          setMessages((current) => current.map((message) => message.id === assistantId
            ? { ...message, content: message.content + chunk }
            : message));
        },
      });
      setFailedRequest(null);
    } catch (requestError) {
      const wasAborted = abortingRef.current
        || (requestError instanceof Error && requestError.name === 'AbortError');
      if (!wasAborted) setError(errorMessage(requestError));
    }
  }, [contextFor, isStreaming, messages, stream]);

  const resetConversation = () => {
    if (isStreaming) {
      abortingRef.current = true;
      abort();
    }
    isAtBottomRef.current = true;
    setShowLatestButton(false);
    setMessages([]);
    setError('');
    setFailedRequest(null);
    setDraft('');
    inputRef.current?.focus();
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    sendQuestion(draft);
  };

  return (
    <div className={isDark ? 'dark' : ''}>
      {!isOpen && (
        <button
          ref={launcherRef}
          type="button"
          className="fixed bottom-4 right-4 z-[10001] inline-flex items-center gap-3 rounded-full border border-[#f1ebdb]/30 bg-[#1c4936] py-2.5 pl-3 pr-4 text-sm font-semibold text-[#f7f3e8] shadow-[0_10px_34px_rgba(25,52,37,0.28)] transition hover:-translate-y-0.5 hover:bg-[#255b43] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a761] focus-visible:ring-offset-2 focus-visible:ring-offset-[#f3f0e6] dark:border-[#d5dfd4]/20 dark:bg-[#234d39] dark:text-[#f1f0e6] dark:hover:bg-[#2d6047] sm:bottom-6 sm:right-6"
          aria-label="Open Farm AI assistant"
          aria-haspopup="dialog"
          aria-expanded={isOpen}
          onClick={() => openChat(true)}
          data-testid="button-open-farm-ai"
        >
          <span className="grid size-8 place-items-center rounded-full bg-[#e6bd7e] text-[#244a36]" aria-hidden="true"><Leaf size={18} strokeWidth={2.1} /></span>
          <span>Ask Farm AI</span>
          <ChevronRight size={16} aria-hidden="true" />
        </button>
      )}
      {isOpen && (
        <section
          className="fixed inset-x-0 bottom-0 z-[10002] mx-auto flex h-[min(760px,92dvh)] w-full max-w-[408px] flex-col overflow-hidden rounded-t-[20px] border border-b-0 border-[#ded9c9] bg-[#fbfaf5] text-[#263b30] shadow-[0_24px_70px_rgba(22,44,31,0.24)] dark:border-[#3c5142] dark:bg-[#19271f] dark:text-[#e8eadf] sm:inset-x-auto sm:bottom-6 sm:right-6 sm:h-[min(690px,calc(100dvh-48px))] sm:rounded-[19px] sm:border"
          role="dialog"
          aria-modal="false"
          aria-labelledby="farm-ai-title"
          aria-describedby="farm-ai-description"
          aria-busy={isStreaming}
          data-testid="panel-farm-ai"
        >
          <header className="flex flex-none items-center justify-between border-b border-white/10 bg-[#1c4936] px-4 py-4 text-[#f7f3e8] dark:bg-[#173a2b]">
            <div className="flex min-w-0 items-center gap-3">
              <div className="grid size-10 flex-none place-items-center rounded-xl bg-[#e6bd7e] text-[#244a36]" aria-hidden="true"><Sparkles size={18} strokeWidth={1.8} /></div>
              <div className="min-w-0">
                <h1 className="font-serif text-xl font-semibold leading-none tracking-tight" id="farm-ai-title">Farm AI</h1>
                <p className="mt-1.5 truncate text-[10px] font-medium tracking-[0.1em] text-[#c5d2c7] dark:text-[#c0d0c1]" id="farm-ai-description">PERMACULTURE, GROUNDED IN THIS FARM</p>
              </div>
            </div>
            <div className="ml-2 flex flex-none items-center gap-1">
              <button type="button" className="grid size-9 place-items-center rounded-lg text-[#e7ede5] transition hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e6bd7e]" onClick={resetConversation} aria-label="Start a new conversation" title="New conversation" data-testid="button-reset-chat">
                <RotateCcw size={16} />
              </button>
              <button
                type="button"
                className="grid size-9 place-items-center rounded-lg text-[#e7ede5] transition hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e6bd7e]"
                onClick={() => setIsDark((current) => !current)}
                aria-label={`Switch to ${isDark ? 'light' : 'dark'} appearance`}
                aria-pressed={isDark}
                title={`Switch to ${isDark ? 'light' : 'dark'} appearance`}
                data-testid="button-toggle-chat-theme"
              >
                {isDark ? <Sun size={17} /> : <Moon size={16} />}
              </button>
              <button type="button" className="grid size-9 place-items-center rounded-lg text-[#e7ede5] transition hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e6bd7e]" onClick={() => openChat(false)} aria-label="Close Farm AI" data-testid="button-close-farm-ai">
                <X size={18} />
              </button>
            </div>
          </header>

          <div
            className="relative min-h-0 flex-1 space-y-3 overflow-y-auto bg-[#fbfaf5] px-4 py-5 scroll-smooth dark:bg-[#19271f]"
            ref={threadRef}
            onScroll={(event) => {
              const element = event.currentTarget;
              const nearBottom = element.scrollHeight - element.scrollTop - element.clientHeight < 72;
              isAtBottomRef.current = nearBottom;
              setShowLatestButton(!nearBottom);
            }}
            aria-live="polite"
            aria-relevant="additions text"
            data-testid="thread-chat"
          >
            {showLatestButton && (
              <button
                type="button"
                className="sticky top-0 z-10 mx-auto flex items-center gap-2 rounded-full border border-[#c9d6c8] bg-[#fbfaf5] px-3 py-1.5 text-xs font-semibold text-[#315b43] shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a761] dark:border-[#49614e] dark:bg-[#263b2d] dark:text-[#e8eadf]"
                onClick={() => {
                  isAtBottomRef.current = true;
                  setShowLatestButton(false);
                  threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight, behavior: 'smooth' });
                }}
                data-testid="button-scroll-latest"
              >
                Latest reply
              </button>
            )}
            {messages.length === 0 ? (
              <div className="px-0.5 py-2">
                <p className="mb-2.5 font-mono text-[10px] font-medium uppercase tracking-[0.13em] text-[#8e7857] dark:text-[#c0ad8c]">A field guide in your corner</p>
                <h2 className="mb-2 font-serif text-2xl font-medium leading-tight tracking-tight text-[#254b37] dark:text-[#d8e5d3]">What would you like to grow?</h2>
                <p className="max-w-[310px] text-[13px] leading-relaxed text-[#6e786f] dark:text-[#b9c5b8]">I can explain what’s on this farm page and help you apply permaculture principles to your own place.</p>
                <div className="mt-3 inline-flex items-center gap-1.5 text-[10px] text-[#6b806e] dark:text-[#b5c8b5]">
                  {knowledgeReady ? <Check size={12} aria-hidden="true" /> : <CircleHelp size={12} aria-hidden="true" />}
                  <span data-testid="status-knowledge-index">{knowledgeReady ? `${knowledgeEntries.length} farm references ready` : 'Reading the farm site…'}</span>
                </div>
                <div className="mt-4 grid gap-2" aria-label="Suggested questions">
                  {starterQuestions.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      className="group flex w-full items-center justify-between gap-3 rounded-xl border border-[#e2dfd3] bg-[#f4f3eb] px-3 py-2.5 text-left text-xs font-medium leading-snug text-[#375645] transition hover:translate-x-0.5 hover:border-[#b2c2af] hover:bg-[#eef2e8] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a761] dark:border-[#3c5744] dark:bg-[#223429] dark:text-[#dce8d9] dark:hover:border-[#5f8068] dark:hover:bg-[#2a4132]"
                      onClick={() => sendQuestion(prompt)}
                      data-testid={`button-prompt-${starterQuestions.indexOf(prompt)}`}
                    >
                      <span>{prompt}</span><ChevronRight className="flex-none transition-transform group-hover:translate-x-0.5" size={15} aria-hidden="true" />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.filter((message) => !(message.role === 'assistant' && !message.content && !isStreaming)).map((message) => (
                <article className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`} key={message.id} data-testid={`message-${message.role}-${message.id}`}>
                  <div
                    className={`max-w-[88%] overflow-hidden rounded-2xl px-3.5 py-3 text-[13px] leading-relaxed ${message.role === 'user'
                      ? 'rounded-br-sm bg-[#315b43] text-[#f8f5ed] dark:bg-[#315b43] dark:text-[#f4f3eb]'
                      : 'rounded-bl-sm bg-[#eeeee4] text-[#34483c] dark:bg-[#26382d] dark:text-[#e8eadf]'}`}
                  >
                    <p className={`mb-1 font-mono text-[9px] font-medium uppercase tracking-[0.1em] ${message.role === 'user' ? 'text-[#d3e0d2]' : 'text-[#8e7857] dark:text-[#b7c9b3]'}`}>
                      {message.role === 'user' ? 'You' : 'Farm AI'}
                    </p>
                    {message.role === 'assistant' && message.content
                      ? <FarmMarkdown content={message.content} />
                      : message.role === 'assistant' && isStreaming
                        ? <div className="flex min-h-7 items-center gap-2 text-xs text-[#65766a] dark:text-[#bdcbbb]" role="status" aria-live="polite" aria-label="Farm AI is writing a response">
                            <span className="flex items-center gap-1" aria-hidden="true">
                              <span className="size-1.5 animate-pulse rounded-full bg-[#63836d]" />
                              <span className="size-1.5 animate-pulse rounded-full bg-[#63836d] [animation-delay:150ms]" />
                              <span className="size-1.5 animate-pulse rounded-full bg-[#63836d] [animation-delay:300ms]" />
                            </span>
                            <span>Thinking through the soil…</span>
                          </div>
                        : <div className="whitespace-pre-wrap break-words">{message.content}</div>}
                    {message.role === 'assistant' && message.content && isStreaming && (
                      <div className="mt-2 flex items-center gap-2 text-[10px] text-[#65766a] dark:text-[#bdcbbb]" role="status" aria-live="polite" aria-label="Farm AI is continuing its response">
                        <span className="flex items-center gap-1" aria-hidden="true">
                          <span className="size-1 animate-pulse rounded-full bg-[#63836d]" />
                          <span className="size-1 animate-pulse rounded-full bg-[#63836d] [animation-delay:150ms]" />
                          <span className="size-1 animate-pulse rounded-full bg-[#63836d] [animation-delay:300ms]" />
                        </span>
                        <span>Writing</span>
                      </div>
                    )}
                  </div>
                </article>
              ))
            )}
            {error && (
              <div className="rounded-xl border border-[#e7c7bd] bg-[#fbefea] px-3 py-2.5 text-xs leading-relaxed text-[#813f32] dark:border-[#7b5045] dark:bg-[#3a2a27] dark:text-[#f0c9bb]" role="alert" data-testid="status-api-error">
                {error}
                {failedRequest && <button type="button" className="ml-1.5 font-bold underline underline-offset-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a761]" onClick={() => sendQuestion(failedRequest.question, failedRequest.history)} data-testid="button-retry-question">Try again</button>}
              </div>
            )}
          </div>

          <form className="flex-none border-t border-[#e8e4d8] bg-[#f8f7f1] px-3.5 pb-3.5 pt-3 dark:border-[#354a3b] dark:bg-[#1d2d23]" onSubmit={submit}>
            <div className="flex items-end gap-2 rounded-[14px] border border-[#d8d9cb] bg-[#fffef9] px-3 py-2 focus-within:border-[#78977e] focus-within:ring-2 focus-within:ring-[#78977e]/20 dark:border-[#465a49] dark:bg-[#223429]">
              <textarea
                ref={inputRef}
                className="min-h-7 max-h-28 min-w-0 flex-1 resize-y bg-transparent py-1 text-[13px] leading-relaxed text-[#293e32] outline-none placeholder:text-[#969b8e] focus-visible:ring-0 dark:text-[#e8eadf] dark:placeholder:text-[#9aa99a]"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    if (draft.trim()) sendQuestion(draft);
                  }
                }}
                placeholder="Ask about soil, water, planting…"
                aria-label="Ask Farm AI a question"
                maxLength={2000}
                rows={Math.min(4, Math.max(1, draft.split('\n').length))}
                data-testid="input-farm-ai-question"
              />
              <button className="grid size-[34px] flex-none place-items-center rounded-[10px] bg-[#315b43] text-[#f8f5ed] transition hover:-translate-y-0.5 hover:bg-[#204833] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d7a761] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0 dark:bg-[#426a4f] dark:hover:bg-[#507a5d]" type="submit" aria-label="Send question" disabled={!draft.trim() || isStreaming} data-testid="button-send-question">
                <ArrowUp size={18} strokeWidth={2.4} />
              </button>
            </div>
            <p className="mb-0 mt-2 px-0.5 font-mono text-[10px] leading-tight text-[#929487] dark:text-[#98a798]">ENTER TO SEND · SHIFT + ENTER FOR A NEW LINE</p>
          </form>
        </section>
      )}
    </div>
  );
}