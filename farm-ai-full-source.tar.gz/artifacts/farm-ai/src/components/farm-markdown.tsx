import type { ReactNode } from 'react';

function safeHref(value: string) {
  const href = value.trim();
  if (/^(https?:|mailto:)/i.test(href) || (href.startsWith('/') && !href.startsWith('//')) || href.startsWith('#')) {
    return href;
  }
  return null;
}

function renderInline(source: string, keyPrefix: string): ReactNode[] {
  const tokenPattern = /(`[^`\n]+`|\[[^\]]+\]\([^)]+\)|\*\*[\s\S]+?\*\*|__[\s\S]+?__|~~[\s\S]+?~~|\*[^*\n]+\*|_[^_\n]+_)/g;
  const output: ReactNode[] = [];
  let cursor = 0;
  let tokenIndex = 0;

  for (const match of source.matchAll(tokenPattern)) {
    const token = match[0];
    const index = match.index ?? 0;
    if (index > cursor) output.push(source.slice(cursor, index));

    const key = `${keyPrefix}-${tokenIndex++}`;
    if (token.startsWith('`')) {
      output.push(<code key={key} className="rounded bg-black/5 px-1 py-0.5 font-mono text-[0.92em] dark:bg-white/10">{token.slice(1, -1)}</code>);
    } else if (token.startsWith('[')) {
      const link = token.match(/^\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)$/);
      const href = link ? safeHref(link[2]) : null;
      output.push(link && href
        ? <a key={key} href={href} target={/^https?:/i.test(href) ? '_blank' : undefined} rel={/^https?:/i.test(href) ? 'noreferrer' : undefined} className="font-medium text-emerald-800 underline decoration-emerald-700/40 underline-offset-2 hover:text-emerald-950 dark:text-emerald-300 dark:hover:text-emerald-200">{renderInline(link[1], key)}</a>
        : token);
    } else if (token.startsWith('**') || token.startsWith('__')) {
      output.push(<strong key={key} className="font-semibold">{renderInline(token.slice(2, -2), key)}</strong>);
    } else if (token.startsWith('~~')) {
      output.push(<del key={key}>{renderInline(token.slice(2, -2), key)}</del>);
    } else {
      output.push(<em key={key}>{renderInline(token.slice(1, -1), key)}</em>);
    }
    cursor = index + token.length;
  }

  if (cursor < source.length) output.push(source.slice(cursor));
  return output;
}

function isBlockStart(lines: string[], index: number) {
  const line = lines[index] ?? '';
  return /^\s*(?:#{1,6}\s|```|>|[-*+]\s|\d+[.)]\s|(?:---+|\*\*\*+|___+)\s*$)/.test(line)
    || (line.includes('|') && /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[index + 1] ?? ''));
}

function parseBlocks(source: string, prefix: string): ReactNode[] {
  const lines = source.replace(/\r\n?/g, '\n').split('\n');
  const blocks: ReactNode[] = [];
  let index = 0;
  let blockIndex = 0;

  while (index < lines.length) {
    const line = lines[index];
    const key = `${prefix}-block-${blockIndex++}`;
    if (!line.trim()) {
      index += 1;
      continue;
    }

    if (/^\s*```/.test(line)) {
      const language = line.trim().slice(3).trim();
      index += 1;
      const codeLines: string[] = [];
      while (index < lines.length && !/^\s*```/.test(lines[index])) codeLines.push(lines[index++]);
      if (index < lines.length) index += 1;
      blocks.push(
        <pre key={key} className="overflow-x-auto rounded-xl border border-black/10 bg-black/[0.04] p-3 text-xs leading-relaxed dark:border-white/10 dark:bg-black/30">
          <code className={language ? `language-${language} font-mono` : 'font-mono'}>{codeLines.join('\n')}</code>
        </pre>,
      );
      continue;
    }

    const heading = line.match(/^\s*(#{1,6})\s+(.*)$/);
    if (heading) {
      const level = heading[1].length;
      const headingClasses = ['text-xl font-semibold', 'text-lg font-semibold', 'text-base font-semibold', 'text-sm font-semibold', 'text-sm font-semibold', 'text-sm font-semibold'];
      const Tag = (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'][level - 1] ?? 'h6') as
        | 'h1'
        | 'h2'
        | 'h3'
        | 'h4'
        | 'h5'
        | 'h6';
      blocks.push(<Tag key={key} className={`${headingClasses[level - 1]} mt-3 first:mt-0`}>{renderInline(heading[2], key)}</Tag>);
      index += 1;
      continue;
    }

    if (/^\s*(?:---+|\*\*\*+|___+)\s*$/.test(line)) {
      blocks.push(<hr key={key} className="border-black/10 dark:border-white/10" />);
      index += 1;
      continue;
    }

    if (/^\s*>/.test(line)) {
      const quoteLines: string[] = [];
      while (index < lines.length && /^\s*>/.test(lines[index])) {
        quoteLines.push(lines[index].replace(/^\s*>\s?/, ''));
        index += 1;
      }
      blocks.push(<blockquote key={key} className="border-l-2 border-emerald-700/40 pl-3 text-muted-foreground dark:border-emerald-300/40">{parseBlocks(quoteLines.join('\n'), key)}</blockquote>);
      continue;
    }

    if (line.includes('|') && /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[index + 1] ?? '')) {
      const cells = (value: string) => value.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((cell) => cell.trim());
      const headers = cells(line);
      index += 2;
      const rows: string[][] = [];
      while (index < lines.length && lines[index].includes('|') && lines[index].trim()) rows.push(cells(lines[index++]));
      blocks.push(
        <div key={key} className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead><tr>{headers.map((cell, cellIndex) => <th key={`${key}-head-${cellIndex}`} className="border-b border-black/10 px-2 py-1.5 font-semibold dark:border-white/10">{renderInline(cell, key)}</th>)}</tr></thead>
            <tbody>{rows.map((row, rowIndex) => <tr key={`${key}-row-${rowIndex}`}>{headers.map((_, cellIndex) => <td key={`${key}-cell-${rowIndex}-${cellIndex}`} className="border-b border-black/5 px-2 py-1.5 dark:border-white/5">{renderInline(row[cellIndex] ?? '', key)}</td>)}</tr>)}</tbody>
          </table>
        </div>,
      );
      continue;
    }

    const listItem = line.match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
    if (listItem) {
      const ordered = /^\d/.test(listItem[1]);
      const items: { text: string; checked?: boolean }[] = [];
      while (index < lines.length) {
        const item = lines[index].match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
        if (!item || /^\d/.test(item[1]) !== ordered) break;
        const task = item[2].match(/^\[([ xX])\]\s+(.*)$/);
        items.push(task
          ? { text: task[2], checked: task[1].toLowerCase() === 'x' }
          : { text: item[2] });
        index += 1;
      }
      const ListTag = ordered ? 'ol' : 'ul';
      blocks.push(
        <ListTag key={key} className={`${ordered ? 'list-decimal' : 'list-disc'} space-y-1 pl-5`}>
          {items.map((item, itemIndex) => (
            <li key={`${key}-item-${itemIndex}`}>
              {item.checked !== undefined && <input type="checkbox" checked={item.checked} readOnly aria-label={item.checked ? 'Completed task' : 'Incomplete task'} className="mr-1.5 accent-emerald-700" />}
              {renderInline(item.text, `${key}-${itemIndex}`)}
            </li>
          ))}
        </ListTag>,
      );
      continue;
    }

    const paragraph: string[] = [line];
    index += 1;
    while (index < lines.length && lines[index].trim() && !isBlockStart(lines, index)) {
      paragraph.push(lines[index++]);
    }
    blocks.push(<p key={key} className="whitespace-pre-wrap">{renderInline(paragraph.join(' '), key)}</p>);
  }

  return blocks;
}

export function FarmMarkdown({ content, className = '' }: { content: string; className?: string }) {
  return (
    <div className={`prose prose-sm max-w-none break-words text-inherit prose-p:my-2 prose-headings:mb-1 prose-headings:mt-3 prose-ul:my-2 prose-ol:my-2 prose-li:my-0 prose-pre:my-2 prose-code:before:content-none prose-code:after:content-none dark:prose-invert ${className}`}>
      {parseBlocks(content, 'farm-markdown')}
    </div>
  );
}