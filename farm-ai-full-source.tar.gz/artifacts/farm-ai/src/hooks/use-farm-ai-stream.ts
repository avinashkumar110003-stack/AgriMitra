import { getStreamFarmAiUrl } from '@workspace/api-client-react';
import type { FarmAiChatInput } from '@workspace/api-client-react';
import { useCallback, useEffect, useRef, useState } from 'react';

type StreamEvent =
  | { type: 'delta'; content: string }
  | { type: 'done' }
  | { type: 'error'; error: string };

type StreamOptions = {
  onDelta: (content: string) => void;
};

function getErrorMessage(payload: unknown, fallback: string) {
  if (payload && typeof payload === 'object' && 'error' in payload) {
    const value = (payload as { error?: unknown }).error;
    if (typeof value === 'string' && value.trim()) return value;
  }
  return fallback;
}

function parseEventFrame(frame: string): StreamEvent | null {
  const data = frame
    .split(/\r?\n/)
    .filter((line) => line.startsWith('data:'))
    .map((line) => line.slice(5).trimStart())
    .join('\n');

  if (!data) return null;
  let event: unknown;
  try {
    event = JSON.parse(data);
  } catch {
    throw new Error('Farm AI sent an invalid response. Please try again.');
  }
  if (!event || typeof event !== 'object' || !('type' in event)) {
    throw new Error('Farm AI sent an invalid response. Please try again.');
  }

  const typedEvent = event as Partial<StreamEvent>;
  if (typedEvent.type === 'delta' && typeof typedEvent.content === 'string') {
    return { type: 'delta', content: typedEvent.content };
  }
  if (typedEvent.type === 'done') return { type: 'done' };
  if (typedEvent.type === 'error' && typeof typedEvent.error === 'string') {
    return { type: 'error', error: typedEvent.error };
  }

  throw new Error('Farm AI sent an invalid response. Please try again.');
}

async function readStream(response: Response, onDelta: (content: string) => void) {
  if (!response.body) {
    throw new Error('Streaming is not available in this browser. Please try again.');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let receivedDone = false;

  const consumeFrame = (frame: string) => {
    const event = parseEventFrame(frame);
    if (!event) return;
    if (event.type === 'delta') onDelta(event.content);
    if (event.type === 'error') throw new Error(event.error);
    if (event.type === 'done') receivedDone = true;
  };

  while (true) {
    const { done, value } = await reader.read();
    buffer += decoder.decode(value, { stream: !done });
    const frames = buffer.split(/\r?\n\r?\n/);
    buffer = frames.pop() ?? '';
    for (const frame of frames) consumeFrame(frame);
    if (done) break;
  }

  if (buffer.trim()) consumeFrame(buffer);
  if (!receivedDone) {
    throw new Error('The response ended before Farm AI finished. Please try again.');
  }
}

export function useFarmAiStream() {
  const [isStreaming, setIsStreaming] = useState(false);
  const controllerRef = useRef<AbortController | null>(null);

  const abort = useCallback(() => {
    const controller = controllerRef.current;
    if (!controller) return;
    controllerRef.current = null;
    controller.abort();
    setIsStreaming(false);
  }, []);

  const stream = useCallback(async (
    data: FarmAiChatInput,
    { onDelta }: StreamOptions,
  ) => {
    controllerRef.current?.abort();
    const controller = new AbortController();
    controllerRef.current = controller;
    setIsStreaming(true);

    try {
      const response = await fetch(getStreamFarmAiUrl(), {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          Accept: 'text/event-stream, application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        signal: controller.signal,
      });

      const contentType = response.headers.get('content-type') ?? '';
      if (!response.ok) {
        let payload: unknown;
        try {
          payload = await response.json();
        } catch {
          payload = null;
        }
        throw new Error(getErrorMessage(payload, 'Farm AI could not answer just now. Please try again.'));
      }

      if (contentType.includes('application/json')) {
        const payload: unknown = await response.json();
        if (payload && typeof payload === 'object' && 'answer' in payload
          && typeof (payload as { answer?: unknown }).answer === 'string') {
          onDelta((payload as { answer: string }).answer);
          return;
        }
        throw new Error(getErrorMessage(payload, 'Farm AI returned an invalid response.'));
      }

      await readStream(response, onDelta);
    } finally {
      if (controllerRef.current === controller) {
        controllerRef.current = null;
        setIsStreaming(false);
      }
    }
  }, []);

  useEffect(() => () => {
    controllerRef.current?.abort();
    controllerRef.current = null;
  }, []);

  return { stream, abort, isStreaming };
}