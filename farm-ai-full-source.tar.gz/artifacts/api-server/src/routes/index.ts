import { Router, type IRouter } from "express";
import farmAiRouter from "./farm-ai";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(farmAiRouter);

export default router;
